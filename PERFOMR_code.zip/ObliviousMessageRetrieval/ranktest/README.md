This is for SRLC2 test.
This file requires (eigen)[https://eigen.tuxfamily.org/dox/GettingStarted.html] library.
Please install eigen and replace ```/pathToEigen``` in Makefile with the path you installed your eigen library and run ```make```.